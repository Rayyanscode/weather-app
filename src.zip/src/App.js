import logo from "./logo.svg";
import "./App.css";
import Template from "./component/template";

function App() {
  return (
    <div className="App">
      <Template />
    </div>
  );
}

export default App;
